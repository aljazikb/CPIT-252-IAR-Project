/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author noufa
 */

import designpattern_cpit2522.DB_Singleton.*;
import static org.testng.Assert.*;
import org.testng.annotations.Test;
public class SingletonTest {
    

public class DBconnectionSingletonTest {
    
    ///tests if there is an instance --> return not null///
    @Test
    public void testSingletonInstance() {
        DBconnectionSingleton instance = DBconnectionSingleton.getConnectionInstance();
        assertNotNull(instance);
    }

    ///tests if both different connection calls are the same or getConnection() has created new instance--> check if 2 diff instnaces ///
    @Test
    public void testSameInstance() {
        DBconnectionSingleton instance1 = DBconnectionSingleton.getConnectionInstance();
        DBconnectionSingleton instance2 = DBconnectionSingleton.getConnectionInstance();

        assertSame(instance1, instance2);
    }

    ///test if the DB is inside the Singleton class and is not null ///
    @Test
    public void testConnection() {
        DBconnectionSingleton instance = DBconnectionSingleton.getConnectionInstance();
        assertNotNull(instance.getConnection());
    }
}

    
}
