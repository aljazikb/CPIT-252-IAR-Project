/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designpattern_cpit2522;

import designpattern_cpit2522.DB_Singleton.DBconnectionSingleton;
import java.io.*;
import java.sql.*;

/**
 *
 * @author noufa
 */
public class GenerateReport {

    //Singleton pattern DB connection
    private final DBconnectionSingleton db = DBconnectionSingleton.getConnectionInstance();
    private final Connection con = db.getConnection();

    public String generateInventoryReport(int managerID) {

        StringBuilder report = new StringBuilder();

        try {

            //selects all the information about the current manager's inventroy and displays it both in the GUI and a text report
            String sql = "SELECT * FROM Inventory WHERE ManagerID = ?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, managerID);
            ResultSet rs = ps.executeQuery();

            //page title
            report.append(String.format("%68s\n"," INVENTORY STOCK REPORT"));

            report.append("Manager ID: ")
                    .append(managerID)
                    .append("\n\n");

            //print the column names of the inventroy
            report.append(String.format("%-10s %-10s %-15s %-10s %-15s %-10s %-15s %-15s\n",
                    "ID",
                    "Name",
                    "Category",
                    "Type",
                    "Unit Price",
                    "Quantity",
                    "Total Value",
                    "Pricing Strategy"
            ));

            //seperator between the column names and information --> table like structure
            report.append("─".repeat(150))
                    .append("\n");

            //data retreived from the DB
            while (rs.next()) {

                int inventoryID = rs.getInt("InventoryID");
                String name = rs.getString("Name");
                String category = rs.getString("Category");
                String specificType = rs.getString("SpecificType");
                double unitPrice = rs.getDouble("UnitPrice");
                int quantity = rs.getInt("QuantityInStock");
                double totalValue = rs.getDouble("InventoryValue");
                String pricingStrategy = rs.getString("PricingStrategy");

                report.append(String.format("%-12d %-20s %-15s %-15s $%-11.2f %-10d $%-14.2f %-30s\n",
                        inventoryID,
                        name,
                        category,
                        specificType,
                        unitPrice,
                        quantity,
                        totalValue,
                        pricingStrategy
                ));
            }

            //saves the file
            PrintWriter writer = new PrintWriter("Report.txt");
            writer.print(report.toString());
            writer.close();
            System.out.println("Report saved");

        } catch (Exception e) {
            e.printStackTrace();
            return "Error generating report.";
        }

        return report.toString();
    }
}
