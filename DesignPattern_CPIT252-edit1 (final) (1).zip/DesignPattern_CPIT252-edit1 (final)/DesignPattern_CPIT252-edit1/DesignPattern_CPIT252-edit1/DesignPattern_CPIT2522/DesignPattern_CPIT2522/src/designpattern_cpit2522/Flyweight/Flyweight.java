/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package designpattern_cpit2522.Flyweight;

/**
 *
 * @author noufa
 */
public interface Flyweight {
    
       String getCategory();

      String getSpecificType();

      String getPricingStrategy();
    
}
