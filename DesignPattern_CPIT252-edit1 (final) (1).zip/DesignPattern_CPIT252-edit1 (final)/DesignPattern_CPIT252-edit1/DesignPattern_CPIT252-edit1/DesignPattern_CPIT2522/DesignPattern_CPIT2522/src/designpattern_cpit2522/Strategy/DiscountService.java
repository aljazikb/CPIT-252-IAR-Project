/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designpattern_cpit2522.Strategy;

import designpattern_cpit2522.DB_Singleton.*;
import java.sql.*;


/**
 *
 * @author aljaz
 */
public class DiscountService {
    //Singleton pattern DB connection
    private final DBconnectionSingleton db = DBconnectionSingleton.getConnectionInstance();
    //calculates the discount based on the user entry
    public void applyDiscount(int inventoryID, DiscountStrategy strategy) throws Exception {

            //Singleton pattern DB connection
            Connection con = db.getConnection();
        try {

            //retrieves the price of single unit and quantity from the inventory
            String query = "SELECT UnitPrice, QuantityInStock FROM Inventory WHERE InventoryID = ?";
            PreparedStatement ps1 = con.prepareStatement(query);
            ps1.setInt(1, inventoryID);
            ResultSet rs = ps1.executeQuery();

            if (!rs.next()) {
                throw new IllegalArgumentException("Product with ID " + inventoryID + " not found.");
            }

            double oldPrice = rs.getDouble("UnitPrice");
            int quantity = rs.getInt("QuantityInStock");

            // Context is the only one that touches the strategy
            Context context = new Context(strategy);
            double newPrice = context.executeDiscount(oldPrice);
            double inventoryValue = newPrice * quantity;

            //updates the new prices and the discount strategy
            String update = "UPDATE Inventory "+ "SET UnitPrice=?, InventoryValue=?, PricingStrategy=? "+ "WHERE InventoryID=?";
            PreparedStatement ps2 = con.prepareStatement(update);
            ps2.setDouble(1, newPrice);
            ps2.setDouble(2, inventoryValue);
            ps2.setString(3, context.getStrategyName());
            ps2.setInt(4, inventoryID);
            ps2.executeUpdate();
        }catch (SQLException e) {
            throw new Exception("Database error while applying discount: " + e.getMessage());
        }
    }

    //builds the strategy based on the chosen field from the GUI
    public DiscountStrategy buildStrategy(String discountType, String percentText) {
        
        if (discountType.equals("Seasonal")) {
            return new SeasonalDiscount();
        }
        double percent = Double.parseDouble(percentText); 
        
        return new PercentageDiscount(percent);
    }

}
